#!/bin/sh
# Copyright (C) 2025-2026 ukriu (Contact: contact@ukriu.com)
# Enhanced & Premium Customize Script for HyperOS Optimization

if ! $BOOTMODE; then
    ui_print "****************************************************"
    ui_print " Warning: Installing from recovery is not recommended!"
    ui_print " The installation will continue, but it is recommended to "
    ui_print " finish the setup via KernelSU/Magisk manager action button!"
    ui_print "****************************************************"
fi

export MODPATH
if [ -f "$MODPATH/utils.sh" ]; then
    . "$MODPATH/utils.sh"
fi

ui_print "- Initializing HyperOS Advanced Unlock & UI Tweaks..."

# Execute standard functions safely if available
if command -v check_supported >/dev/null 2>&1; then
    check_supported
fi

if command -v bypass_hyperos_restrict >/dev/null 2>&1; then
    bypass_hyperos_restrict true
fi

if command -v disable_incompatible_modules >/dev/null 2>&1; then
    disable_incompatible_modules
fi

if command -v save_deviceLevelList >/dev/null 2>&1; then
    save_deviceLevelList
fi

# Forcefully apply UI and control center properties during install
ui_print "- Applying Premium Split Control Center & Animation Flags..."
setprop persist.sys.use_control_center true
setprop ro.miui.has_handy_mode_sf 1
setprop config.disable_expand_notification false
setprop ro.miui.launcher.animation.style 1
setprop persist.sys.miui_optimization true
setprop ro.miui.ui.version.code 14

if command -v blur_choice >/dev/null 2>&1; then
    blur_choice
fi

if command -v highend_choice >/dev/null 2>&1; then
    highend_choice
fi

if command -v ssblur_choice >/dev/null 2>&1; then
    ssblur_choice
fi

# Island configuration check
case "$(getprop persist.sys.feature.island)" in
    "0"|false)
        CHOICE_ISLAND=false
        ;;
    *)
        CHOICE_ISLAND=true
        setprop persist.sys.feature.island true
        setprop persist.sys.feature.island.animation true
        ;;
esac

for func in define_props qs_choice xml_init update_desc warning credits; do
    if command -v "$func" >/dev/null 2>&1; then
        "$func"
    fi
done

ui_print "****************************************************"
ui_print "  Installation Successful! Reboot your device.      "
ui_print "****************************************************"

exit 0
# EOF