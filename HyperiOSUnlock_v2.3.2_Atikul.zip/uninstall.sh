#!/bin/sh
# Copyright (C) 2025-2026 Atikul (Contact: developer.atikul@gmail.com)
# Read LICENSE_NOTICE.txt for further info.

# Load utility functions safely if exists
if [ -f "./utils.sh" ]; then
    . ./utils.sh
fi

echo "[*] Cleaning up HyperiOSUnlock configurations..."

# Restore device settings safely if function exists
if command -v restore_deviceLevelList >/dev/null 2>&1; then
    restore_deviceLevelList
fi

# Remove residual module directory files safely
if [ -d "/data/adb/HyperUnlocked" ]; then
    rm -rf /data/adb/HyperUnlocked
fi

if [ -d "/data/adb/HyperiOSUnlock" ]; then
    rm -rf /data/adb/HyperiOSUnlock
fi

# Reset background blur or security flags if necessary
settings put secure background_blur_enable 0

echo "[✔] Uninstall and cleanup completed successfully!"
exit 0
# EOF