#!/system/bin/sh
MODDIR=${0%/*}

# Wait for boot completion
until [ "$(getprop sys.boot_completed)" = "1" ]; do
    sleep 3
done

# Apply system property overrides for control center and layout
setprop persist.sys.use_control_center true
setprop ro.miui.launcher.animation.style 1
setprop persist.sys.miui_optimization true