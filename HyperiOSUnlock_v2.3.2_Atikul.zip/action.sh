#!/bin/sh
# Enhanced Hyper Unlock & iOS UI Activator Script

# Load utility functions safely if exists
if [ -f "./utils.sh" ]; then
    . ./utils.sh
fi

# Bypass system restrictions and enforce properties
if command -v bypass_hyperos_restrict >/dev/null 2>&1; then
    bypass_hyperos_restrict true
fi

if command -v disable_incompatible_modules >/dev/null 2>&1; then
    disable_incompatible_modules
fi

# Forcefully inject iOS Style and Split Control Center Properties
setprop persist.sys.use_control_center true
setprop ro.miui.has_handy_mode_sf 1
setprop config.disable_expand_notification false
setprop ro.miui.launcher.animation.style 1
setprop persist.sys.miui_optimization true
setprop ro.miui.ui.version.code 14

# Island configuration fallback check
case "$(getprop persist.sys.feature.island)" in
    "0"|false)
        CHOICE_ISLAND=false
        ;;
    *)
        CHOICE_ISLAND=true
        setprop persist.sys.feature.island true
        ;;
esac

# Execute underlying module functions if available
for func in define_props ssblur_choice qs_choice xml_init update_desc warning credits; do
    if command -v "$func" >/dev/null 2>&1; then
        "$func"
    fi
done

echo ""
echo "[✔] HyperOS iOS Layout & Control Center successfully forced!"
echo "[!!] A system reboot is required for changes to take effect."
echo ""

sleep 1
exit 0
# EOF