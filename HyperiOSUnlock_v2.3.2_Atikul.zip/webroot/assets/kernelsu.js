/**
 * Imported from official KernelSU package
 * Enhanced & Maintained by Atikul (Contact: amd379629@gmail.com)
 * Module: HyperiOSUnlock / KernelSU Bridge API v2.3.2
 */

let callbackCounter = 0;
function getUniqueCallbackName(prefix) {
    return `${prefix}_callback_${Date.now()}_${callbackCounter++}`;
}

/**
 * Execute shell command securely with ksu.exec
 * @param {string} command - The command to execute
 * @param {Object} [options={}] - Options object containing cwd and env
 * @returns {Promise<Object>} Resolves with errno, stdout, and stderr
 */
function exec(command, options = {}) {
    return new Promise((resolve, reject) => {
        const callbackFuncName = getUniqueCallbackName("exec_atikul");
        window[callbackFuncName] = (errno, stdout, stderr) => {
            resolve({ errno, stdout, stderr });
            cleanup(callbackFuncName);
        };
        function cleanup(successName) {
            delete window[successName];
        }
        try {
            if (typeof ksu !== 'undefined') {
                ksu.exec(command, JSON.stringify(options), callbackFuncName);
            } else {
                resolve({ errno: 1, stdout: "", stderr: "KernelSU bridge (ksu) is not defined." });
            }
        } catch (error) {
            reject(error);
            cleanup(callbackFuncName);
        }
    });
}

/**
 * Standard I/O stream for child processes.
 * @class
 */
class Stdio {
    constructor() {
        this.listeners = {};
    }
    on(event, listener) {
        if (!this.listeners[event]) {
            this.listeners[event] = [];
        }
        this.listeners[event].push(listener);
    }
    emit(event, ...args) {
        if (this.listeners[event]) {
            this.listeners[event].forEach(listener => listener(...args));
        }
    }
}

/**
 * Spawn shell process with ksu.spawn
 * @param {string} command - The command to execute
 * @param {string[]} [args=[]] - Arguments array
 * @param {Object} [options={}] - Options containing cwd and env
 * @returns {Object} Child process object with standard streams and event handlers
 */
function spawn(command, args = [], options = {}) {
    const child = {
        listeners: {},
        stdout: new Stdio(),
        stderr: new Stdio(),
        stdin: new Stdio(),
        on(event, listener) {
            if (!this.listeners[event]) this.listeners[event] = [];
            this.listeners[event].push(listener);
        },
        emit(event, ...args) {
            if (this.listeners[event]) {
                this.listeners[event].forEach(listener => listener(...args));
            }
        }
    };
    const callbackName = getUniqueCallbackName("spawn_atikul");
    window[callbackName] = child;
    child.on("exit", () => delete window[callbackName]);
    try {
        if (typeof ksu !== 'undefined') {
            ksu.spawn(command, JSON.stringify(args), JSON.stringify(options), callbackName);
        } else {
            setTimeout(() => {
                child.stderr.emit("data", "KernelSU bridge (ksu) is not defined.");
                child.emit("exit", 1);
            }, 0);
        }
    } catch (error) {
        child.emit("error", error);
        delete window[callbackName];
    }
    return child;
}

/**
 * Request WebView enter/exit full screen state.
 * @param {Boolean} isFullScreen - Full screen status
 */
function fullScreen(isFullScreen) {
    if (typeof ksu !== 'undefined') {
        ksu.fullScreen(isFullScreen);
    }
}

/**
 * Request WebView edge-to-edge / insets configuration.
 * @param {Boolean} isEnable - Enable state
 */
function enableEdgeToEdge(isEnable) {
    return new Promise((resolve, reject) => {
        if (typeof ksu !== 'undefined') {
            if (typeof ksu.enableEdgeToEdge === 'function') {
                ksu.enableEdgeToEdge(isEnable);
                resolve(true);
            } else if (typeof ksu.enableInsets === 'function') {
                ksu.enableInsets(isEnable);
                resolve(true);
            } else {
                reject(new Error("ksu.enableEdgeToEdge or ksu.enableInsets is unavailable. Contact Atikul at amd379629@gmail.com"));
            }
        } else {
            reject(new Error("KernelSU (ksu) is not defined."));
        }
    });
}

/**
 * Show Android Toast message via KernelSU bridge.
 * @param {string} message - Message to display
 */
function toast(message) {
    if (typeof ksu !== 'undefined') {
        ksu.toast(message);
    } else {
        console.log(`[Atikul Toast]: ${message}`);
    }
}

/**
 * List installed packages on device.
 * @param {string} [type="all"] - "user", "system", or "all"
 * @returns {Promise<string[]>} Array of package names
 */
async function listPackages(type) {
    if (typeof globalThis.ksu?.listPackages === 'function') {
        try {
            return JSON.parse(ksu.listPackages(type));
        } catch (error) {
            // Fallback handled below
        }
    }

    return new Promise((resolve, reject) => {
        const pmArgs = {
            all: [],
            user: ['-3'],
            system: ['-s'],
        };

        if (!(type in pmArgs)) {
            return reject(new Error(`Unknown listPackages type: ${type}`));
        }

        let pkgs = [];
        let stderr = '';

        const pm = spawn('pm', ['list', 'packages', ...pmArgs[type]]);
        pm.stdout.on('data', (data) => {
            if (data.trim() !== '') {
                pkgs.push(data.trim().replace(/^package:/, ''));
            }
        });
        pm.stderr.on('data', (data) => (stderr += data));
        pm.on('exit', (code) => {
            if (code !== 0) {
                return reject(new Error(`pm process exited with code ${code}: ${stderr.trim()}`));
            }
            resolve(pkgs);
        });
        pm.on('error', (error) => {
            reject(error);
        });
    });
}

/**
 * Retrieve detailed package information.
 * @param {string|string[]} pkg - Package name or array of names
 * @returns {Promise<Object|Object[]>} Package info object(s)
 */
function getPackagesInfo(pkg) {
    return new Promise((resolve, reject) => {
        if (!pkg) {
            return resolve([]);
        }

        if (typeof globalThis.ksu?.getPackagesInfo !== 'function') {
            return reject(new Error("ksu.getPackagesInfo is not available."));
        }

        const pkgs = Array.isArray(pkg) ? pkg : [pkg];
        if (pkgs.length === 0) {
            return resolve([]);
        }

        try {
            const infoJson = ksu.getPackagesInfo(JSON.stringify(pkgs));
            const result = JSON.parse(infoJson);
            
            if (!Array.isArray(pkg) && result.length === 1) {
                resolve(result[0]);
            } else {
                resolve(result);
            }
        } catch (error) {
            reject(new Error(`Failed to get package info: ${error.message}`));
        }
    });
}

export { exec, spawn, fullScreen, enableEdgeToEdge, toast, listPackages, getPackagesInfo };